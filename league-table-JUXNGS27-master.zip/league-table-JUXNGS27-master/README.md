# league-table
*Escribe un programa PHP que permita al usuario introducir los
nombres de los equipos que participan un una liga de fútbol. Con dichos nombres
la aplicación mostrará al usuario todos los partidos que conforman la 
competicion. El usuario podrá rellenar los resultados de dichos partidos
y enviarlos de vuelta a la aplicación que finalmente mostrará en pantalla 
la clasificación final que incluye puntos y goles conseguidos y encajados. 
Ten en cuenta que si dos equipos han terminado con los mismos puntos se 
deberá decidir por la diferencia de goles marcados y encajados (gol average). 
Si aún así hay empate podremos desempatar por su orden alfabético.*


1. Estructuras de control variadas
2. Utilización de arrays bidimensionales
3. Ordenación de arrays 
4. Uso de Funciones de usuario
5. Envío de bloques de información desde el formulario
6. Ordenación de arrays. multisort
7. Uso de composer
8. Generación de vistas con motor de vistas BladeOne
9. Arquitectura controlador y vistas. Patrón MVC
