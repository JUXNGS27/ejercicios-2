@extends('app')
@section('content')
    @component('board')
    @endcomponent
@endsection
