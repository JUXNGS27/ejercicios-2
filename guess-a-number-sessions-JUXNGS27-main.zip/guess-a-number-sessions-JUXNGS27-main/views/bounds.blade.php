@extends('app')
@section('title', 'Form to enter bounds for guess a number Game')
@section('content')
<form class="form-font" name="form_bounds" 
      action="index.php" method="POST">
    <div class="form-section">
        <label for="lowerbound">Lower bound:</Label> 
        <input autofocus id="lowerbound" type="number"  required name="lowerbound" min="0"/> 
    </div>
    <div class="form-section">
        <label for="upperbound">Upper bound:</Label> 
        <input id="upperbound" type="number"  required name="upperbound" min="1"/> 
    </div>
    @if (!empty($boundsError))
    <p class="info-section">Upper bound must be higher than lower bound</p>
    @endif
    <div class="submit-section-2">
        <input type="submit" 
               value="Send" name="boundsbutton" /> 
    </div>
</form>   
@endSection