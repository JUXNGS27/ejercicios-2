<?php
require "vendor/autoload.php";

use eftec\bladeone\BladeOne;

$views = __DIR__ . '\views';
$cache = __DIR__ . '\cache';

$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);

if (empty($_POST)) {
    echo $blade->run('bounds');
} else if (filter_input(INPUT_POST, "boundsbutton")) {
    $ciudadesFiltro = filter_input(INPUT_POST, "ciudades");
    $ciudades = array_filter(explode(",", $ciudadesFiltro), 'strlen');
    $error = false;
    $error_texto = "";
    if (empty($ciudadesFiltro) || empty($ciudades)) {
        $error = true;
        $error_texto = "No puede estar vacio";
    }
    if ($error) {
        echo $blade->run('bounds', ["texto" => $ciudadesFiltro, "error" => $error_texto]);
    } else {
        $temperaturas = [];
        $meses = [
            1 => 'Enero', 2 => 'Febrero', 3 => 'Marzo', 4 => 'Abril',
            5 => 'Mayo', 6 => 'Junio', 7 => 'Julio', 8 => 'Agosto',
            9 => 'Septiembre', 10 => 'Octubre', 11 => 'Noviembre', 12 => 'Diciembre'
        ];

        foreach ($ciudades as $ciudad) {
            foreach ($meses as $numeroMes => $nombreMes) {
                $temperaturaMaxima = rand(20, 45);
                $temperaturaMinima = rand(-15, 20);

                $temperaturas[$ciudad][$nombreMes]['maxima'] = $temperaturaMaxima;
                $temperaturas[$ciudad][$nombreMes]['minima'] = $temperaturaMinima;
            }
        }

        echo $blade->run('tabla', ['ciudades' => $ciudades, 'meses' => $meses, 'temperaturas' => $temperaturas]);
    }
} else if (filter_input(INPUT_POST, "tablaButton")) {
    $temperaturas = filter_input(INPUT_POST, "temperaturas", FILTER_DEFAULT, FILTER_REQUIRE_ARRAY);
    $ciudades = array_keys($temperaturas);

    $temperaturaFinal = [];
    foreach ($temperaturas as $ciudad => $meses) {
        $max = max(array_column($meses, "max"));
        $min = min(array_column($meses, "min"));
        $sumMax = array_sum(array_column($meses, "max"));
        $sumMin = array_sum(array_column($meses, "min"));
        $nMax = count(array_column($meses, "max"));
        $nMin = count(array_column($meses, "min"));
        $media = round((($sumMax + $sumMin) / ($nMax + $nMin)));
        $temperaturaFinal[$ciudad] = ['nombre' => $ciudad, 'min' => $min, 'max' => $max, 'media' => $media];
    }

    $maxColum = array_column($temperaturaFinal, "max");
    $minColum = array_column($temperaturaFinal, "min");
    $nombreColum = array_column($temperaturaFinal, "nombre");
    array_multisort($maxColum, SORT_DESC, $minColum, SORT_ASC, $nombreColum, $temperaturaFinal);
    echo $blade->run("final", ["temperaturaFinal" => $temperaturaFinal, "ciudades" => $ciudades]);
} else {
    echo $blade->run('bounds');
}
