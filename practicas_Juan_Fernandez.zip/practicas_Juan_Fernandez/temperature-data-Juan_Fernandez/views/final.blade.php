@extends('app')
@section('title', 'Form to enter bounds for guess a number Game')
@section('content')
<form class="form-font capaform" name="form_bounds" action="index.php" method="POST">
    <div class="flex-outer">
        <div class="tabla">
            <table>
                <tr>
                    <th>Ciudad</th>
                    <th>Mínima</th>
                    <th>Máximo</th>
                    <th>Media</th>
                </tr>
                @foreach($ciudades as $ciudad)
                <tr>
                    <td>{{ $ciudad }}</td>
                    <td>{{ $temperaturaFinal[$ciudad]['min'] }}</td>
                    <td>{{ $temperaturaFinal[$ciudad]['max'] }}</td>
                    <td>{{ $temperaturaFinal[$ciudad]['media'] }}</td>
                </tr>
                @endforeach
            </table>
        </div>
    </div>
    <div class="submit-section">
        <input class="submit" type="submit" value="Send" name="finalButton" />
    </div>
</form>
@endSection