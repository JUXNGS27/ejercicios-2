<html>

<head>
    <title>@yield('title')</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="/public/assets/css/stylesheet.css">
</head>

<body>
    <div class="flex-page">
        <h1>Temperatures</h1>
        @yield('content')
    </div>
</body>

</html>