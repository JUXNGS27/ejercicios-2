<?php

//Cargamos las dependencias de bladeone
require 'vendor/autoload.php';
use eftec\bladeone\BladeOne;

//iniciamos la sesion
session_start();

//configuramos las rutas
$views = __DIR__ . '/views';
$cache = __DIR__ . '/cache';
$blade = new BladeOne($views, $cache, BladeOne::MODE_DEBUG);


//verificamos que el metodo es post
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    //para equipos
    if (isset($_POST['team_names'])) {
        //Guardamos los equipos de froma separada, eliminando los espacios
        $teamNames = array_map('trim', explode("\n", $_POST['team_names']));
        //guardamos en las sesiones correspondientes los partidos y los equipos
        $_SESSION['teams'] = $teamNames;
        $_SESSION['matches'] = generateMatches($teamNames);
        //mostramos la vista de partidos que han sido generados
        echo $blade->run('matches_form', ['matches' => $_SESSION['matches']]);
    } elseif (isset($_POST['match_results'])) {
        //carga los partidos en la variable resultados
        $results = $_POST['match_results'];
        //guardamos los resultados
        $_SESSION['standings'] = calculateStandings($_SESSION['teams'], $results);
        //mostramos la vista estandings
        echo $blade->run('standings', ['standings' => $_SESSION['standings']]);
    }
} else {
    //si la solicitud es get muestra el formulario teams_form que es donde le pasamos los equipos
    echo $blade->run('teams_form');
}

//es una funcion para asegurarnos que todos los equipos juegan entre ellos
function generateMatches($teams) {
    $matches = [];
    for ($i = 0; $i < count($teams); $i++) {
        for ($j = $i + 1; $j < count($teams); $j++) {
            $matches[] = ['team1' => $teams[$i], 'team2' => $teams[$j]];
        }
    }
    return $matches;
}

//es una funcion que calcula la clasificacion de cada equipo en base a los puntos y la diferencia de goles
function calculateStandings($teams, $results) {
    $standings = [];
    foreach ($teams as $team) {
        $standings[$team] = ['points' => 0, 'scored' => 0, 'conceded' => 0];
    }
//procesa los resultados de cada partido, actualizando las estadisticas de cada equipo en la clasificacion
    foreach ($results as $match => $result) {
        list($team1, $team2) = explode('-', $match);
        $team1Goals = (int)$result['team1'];
        $team2Goals = (int)$result['team2'];
        //saca de la vista standings los goles a favor y en contra
        $standings[$team1]['scored'] += $team1Goals;
        $standings[$team1]['conceded'] += $team2Goals;
        $standings[$team2]['scored'] += $team2Goals;
        $standings[$team2]['conceded'] += $team1Goals;
        //depende de los goles, asigna los puntos a cada equipo
        if ($team1Goals > $team2Goals) {
            $standings[$team1]['points'] += 3;
        } elseif ($team2Goals > $team1Goals) {
            $standings[$team2]['points'] += 3;
        } else {
            $standings[$team1]['points'] += 1;
            $standings[$team2]['points'] += 1;
        }
    }

    // Ordenar la clasificacion por puntos, diferencia de goles y luego por nombre de equipos
    array_multisort(
        array_column($standings, 'points'), SORT_DESC,
        array_map(function($team) { return $team['scored'] - $team['conceded']; }, $standings), SORT_DESC,
        array_keys($standings), SORT_ASC,
        $standings
    );

    return $standings;
}
?>
