<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Partidos de la Liga</title>
</head>
<body>
    <h1>Introduce los Resultados</h1>
    <form method="POST" action="">
        @foreach($matches as $match)
            <label>{{ $match['team1'] }} vs {{ $match['team2'] }}:</label>
            <input type="number" name="match_results[{{ $match['team1'] }}-{{ $match['team2'] }}][team1]" required min="0">
            -
            <input type="number" name="match_results[{{ $match['team1'] }}-{{ $match['team2'] }}][team2]" required min="0">
            <br>
        @endforeach
        <input type="submit" value="Calcular Clasificación">
    </form>
</body>
</html>