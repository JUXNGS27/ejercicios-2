<?php

namespace App;

class GuessNumber {
    private $min;
    private $max;
    private $intentos;
    private $numSecreto;
    
    public function __construct($min, $max, $intentos) {
        $this->min = $min;
        $this->max = $max;
        $this->intentos = $intentos;
        $this->numSecreto = rand($min, $max);
    }
    
    public function getMin() {
        return $this->min;
    }
    
    public function getMax() {
        return $this->max;
    }
    
    public function getIntentosRestantes() {
        return $this->intentos;
    }
    
    public function getSecreto() {
        return $this->numSecreto;
    }
    
    public function comprobar($valor) {
        $this->intentos--;
        if ($valor === $this->numSecreto) {
            return "has ganado";
        } else if ($this->intentos <= 0) {
            return "has perdido";
        } else {
            return $valor < $this->numSecreto ? "es mayor" : "es menor";
        }
    }
}
